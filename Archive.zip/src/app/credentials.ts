export const credentials = {
  firebase: {
    apiKey: "AIzaSyCj3MSy-FMPWfLMC_7oSvudVyLQHPsjrqY",
    authDomain: "my-pt-zim-fb13e.firebaseapp.com",
    databaseURL: "https://my-pt-zim-fb13e.firebaseio.com",
    projectId: "my-pt-zim-fb13e",
    storageBucket: "my-pt-zim-fb13e.appspot.com",
    messagingSenderId: "345553986025",
    appId: "1:345553986025:web:2a1de8c1c6e15d978dab78"}
};

export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyBwpjvFVHuf2M-0nijTTue3D4Gbrbj62a4",
    authDomain: "hekima-karibu-nyumbani.firebaseapp.com",
    projectId: "hekima-karibu-nyumbani",
    storageBucket: "hekima-karibu-nyumbani.appspot.com",
    messagingSenderId: "584298090292",
    appId: "1:584298090292:web:a543d7d87032228c419f61",
    measurementId: "G-XQZNG9G9D5"
  }
};
